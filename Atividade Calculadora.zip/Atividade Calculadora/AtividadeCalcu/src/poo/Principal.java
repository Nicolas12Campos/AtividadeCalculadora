package poo;

import javax.swing.JOptionPane;

public class Principal{

	public static void main(String[] args) {
		
		CalculadoraCientifica calculadoCientifica = new CalculadoraCientifica();
		
		int menu = 0;
		
		do {
			
			menu = Integer.parseInt(JOptionPane.showInputDialog("CALCULADORA" + 
																"\n" + 
																"\n1 - Somar" + 
																"\n2 - Subtrair" + 
																"\n3 - Dividir" + 
																"\n4 - Multiplicar" + 
																"\n5 - Potência" + 
																"\n6 - Raiz Quadrada" + 
																"\n0 - sair"));
			
			switch (menu) {
			case 0:
				JOptionPane.showMessageDialog(null, "Obrigado por usar o programa");
				break;
			case 1:
				JOptionPane.showMessageDialog(null, "Resultado: " + calculadoCientifica.Somar());
				break;
			case 2:
				JOptionPane.showMessageDialog(null, "Resultado: " + calculadoCientifica.Subtrair());
				break;
			case 3:
				calculadoCientifica.Dividir();
				if(calculadoCientifica.getValor2() == 0) { 
					JOptionPane.showMessageDialog(null, "ERRO");
				}else {
					JOptionPane.showMessageDialog(null,"Resultado: " + calculadoCientifica.getResultado());
				}
				break;
			case 4:
				JOptionPane.showMessageDialog(null,"Resultado: " + calculadoCientifica.Multiplicar());
				break;
			case 5:
				JOptionPane.showMessageDialog(null, calculadoCientifica.Potencia(calculadoCientifica.getValor2()));
				break;
			case 6:
				calculadoCientifica.RaizQuadrada();
				break;
			default:
				JOptionPane.showMessageDialog(null, "Opção inválida");
				break;
			}
			
		}while(menu != 0);

	}}
