package poo;

import javax.swing.JOptionPane;

public class CalculadoraCientifica extends Calculadora {

	public CalculadoraCientifica() {
		super();
	}

	public CalculadoraCientifica(double valor1, double valor2, double resultado) {
		super(0.0,0.0,0.0);
	}
	
	
	public double Somar() {
		return super.Somar();
	}
	public double Subtrair() {
		return super.Subtrair();
	}
	public double Dividir() {
		return super.Dividir();
	}
	public double Multiplicar() {
		return super.Multiplicar();
	}
	
	public double Potencia(double valor1) {
		super.Ler();
		valor1 = getValor1();
		double resultado = Math.pow(valor1, 2);
		setResultado(resultado); 
		return resultado;
		
	}
	public void RaizQuadrada() {
		super.Ler();
		double resultado = Math.sqrt(getValor2());
		super.setResultado(resultado);
		JOptionPane.showMessageDialog(null, "a raiz quadrada de " + getValor2() + " é " + getResultado());
	}
}
